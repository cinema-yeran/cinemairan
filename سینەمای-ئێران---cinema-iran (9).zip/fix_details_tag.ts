import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split(/\r?\n/);

// We know line 4716 is "                          })}"
// line 4717 is "                        </div>"
// line 4718 is "              )}"
// Let's verify and insert right there
if (lines[4715].trim() === '})}' && lines[4716].trim() === '</div>' && lines[4717].trim() === ')}') {
  lines.splice(4717, 0, '                      </div>');
  fs.writeFileSync(filePath, lines.join('\r\n'), 'utf8');
  console.log("Successfully patched details view tag by precise line insertion!");
} else {
  console.error("Mismatch on expected lines content!");
}
