import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

// We focus on lines 8217 (index 8216) to 8876 (index 8875)
let parenStack: { line: number; col: number; char: string }[] = [];
let braceStack: { line: number; col: number; char: string }[] = [];

for (let i = 8216; i <= 8875; i++) {
  const lineText = lines[i];
  if (!lineText) continue;
  
  // Skip comment lines or text within string literals for simplicity (or just count all)
  for (let col = 0; col < lineText.length; col++) {
    const char = lineText[col];
    if (char === '(') {
      parenStack.push({ line: i + 1, col: col + 1, char });
    } else if (char === ')') {
      if (parenStack.length === 0) {
        console.log(`Extra ')' at Line ${i + 1}:${col + 1}`);
      } else {
        parenStack.pop();
      }
    } else if (char === '{') {
      braceStack.push({ line: i + 1, col: col + 1, char });
    } else if (char === '}') {
      if (braceStack.length === 0) {
        console.log(`Extra '}' at Line ${i + 1}:${col + 1}`);
      } else {
        braceStack.pop();
      }
    }
  }
}

console.log("Unclosed parentheses in the range:", parenStack.map(p => `Line ${p.line}:${p.col}`).join(', '));
console.log("Unclosed braces in the range:", braceStack.map(b => `Line ${b.line}:${b.col}`).join(', '));
