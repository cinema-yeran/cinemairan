import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');

function countOccurrences(str: string, pat: string): number {
  let count = 0;
  let pos = 0;
  while ((pos = str.indexOf(pat, pos)) !== -1) {
    count++;
    pos += pat.length;
  }
  return count;
}

// Ensure we don't count self-closing tags as opening ones if they end in />
// So we can count:
// 1. opening divs: <div (not followed by self-closing, though divs are rarely self-closing)
// 2. closing divs: </div>

const openMain = countOccurrences(content, '<main');
const closeMain = countOccurrences(content, '</main>');

const openForm = countOccurrences(content, '<form');
const closeForm = countOccurrences(content, '</form>');

const openSection = countOccurrences(content, '<section');
const closeSection = countOccurrences(content, '</section>');

const openNav = countOccurrences(content, '<nav');
const closeNav = countOccurrences(content, '</nav>');

console.log(`Main:   Open=${openMain}   Close=${closeMain}`);
console.log(`Form:   Open=${openForm}   Close=${closeForm}`);
console.log(`Section:Open=${openSection}Close=${closeSection}`);
console.log(`Nav:    Open=${openNav}    Close=${closeNav}`);

// For divs, we can count total "<div" vs "</div>"
const totalOpenDiv = countOccurrences(content, '<div');
const totalCloseDiv = countOccurrences(content, '</div>');
console.log(`Divs:   Total Open=${totalOpenDiv}   Total Close=${totalCloseDiv}`);
