import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

// Profile block range: line 8444 (index 8443) to line 8876 (index 8875)
const targetLines = lines.slice(8443, 8876);
const block = targetLines.join('\n');

const stack: { name: string; line: number; text: string }[] = [];

let pos = 0;
while (pos < block.length) {
  const nextOpen = block.indexOf('<', pos);
  if (nextOpen === -1) break;
  
  if (block.substring(nextOpen, nextOpen + 4) === '<!--') {
    const nextClose = block.indexOf('-->', nextOpen);
    pos = nextClose === -1 ? block.length : nextClose + 3;
    continue;
  }
  if (block.substring(nextOpen, nextOpen + 3) === '{/*') {
    const nextClose = block.indexOf('*/}', nextOpen);
    pos = nextClose === -1 ? block.length : nextClose + 3;
    continue;
  }
  
  const endBracket = block.indexOf('>', nextOpen);
  if (endBracket === -1) {
    pos = nextOpen + 1;
    continue;
  }
  
  const rawTag = block.substring(nextOpen + 1, endBracket).trim();
  pos = endBracket + 1;
  
  if (rawTag.endsWith('/') || rawTag.startsWith('/*') || rawTag.startsWith('!')) {
    continue;
  }
  
  if (rawTag.startsWith('/')) {
    const name = rawTag.substring(1).trim().split(/[\s>]/)[0];
    if (name === 'div') {
      if (stack.length === 0) {
        // Calculate original line number in full file
        const beforeStr = block.substring(0, nextOpen);
        const subLine = beforeStr.split('\n').length;
        const actualLine = 8444 + subLine - 1;
        console.log(`Unmatched closing </div> at Line ${actualLine}: "${lines[actualLine - 1].trim()}"`);
      } else {
        stack.pop();
      }
    }
  } else {
    const name = rawTag.split(/[\s>]/)[0];
    if (name === 'div') {
      const beforeStr = block.substring(0, nextOpen);
      const subLine = beforeStr.split('\n').length;
      const actualLine = 8444 + subLine - 1;
      stack.push({ name: 'div', line: actualLine, text: lines[actualLine - 1] });
    }
  }
}

console.log("=== REMAINING OPEN DIVS inside Profile Block ===");
for (const entry of stack) {
  console.log(`Line ${entry.line}: "${entry.text.trim()}"`);
}
