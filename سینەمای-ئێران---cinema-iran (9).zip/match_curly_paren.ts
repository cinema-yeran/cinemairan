import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

// We trace ( and { from line 5894 to 8880
const stack: { char: string; line: number; col: number; text: string }[] = [];

for (let i = 5893; i < 8879; i++) {
  const lineText = lines[i];
  if (!lineText) continue;
  
  for (let col = 0; col < lineText.length; col++) {
    const char = lineText[col];
    if (char === '(' || char === '{') {
      stack.push({ char, line: i + 1, col: col + 1, text: lineText.trim() });
    } else if (char === ')' || char === '}') {
      const expected = char === ')' ? '(' : '{';
      if (stack.length === 0) {
        console.log(`Unmatched closing ${char} at Line ${i + 1}:${col + 1} "${lineText.trim()}"`);
      } else {
        const last = stack[stack.length - 1];
        if (last.char === expected) {
          stack.pop();
        } else {
          // Find if there's a match deeper down
          let found = false;
          for (let s = stack.length - 1; s >= 0; s--) {
            if (stack[s].char === expected) {
              // Popup everything up to s
              stack.splice(s);
              found = true;
              break;
            }
          }
          if (!found) {
            console.log(`Mismatch: found ${char} at Line ${i + 1}:${col + 1} but top of stack is ${last.char} from Line ${last.line}:${last.col}`);
          }
        }
      }
    }
  }
}

console.log("Remaining open matching stack:", stack.map(s => `${s.char} (Line ${s.line}:${s.col} - ${s.text})`).join('\n'));
