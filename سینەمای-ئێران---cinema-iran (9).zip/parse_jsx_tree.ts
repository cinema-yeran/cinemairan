import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

const stack: { type: 'tag' | 'brace' | 'paren'; name: string; line: number; col: number; text: string }[] = [];

const voidTags = new Set(['input', 'img', 'br', 'hr', 'meta', 'link', 'source', 'iframe']);

for (let i = 8216; i <= 8875; i++) {
  const lineText = lines[i];
  if (!lineText) continue;
  
  let pos = 0;
  while (pos < lineText.length) {
    const char = lineText[pos];
    
    if (char === '{') {
      stack.push({ type: 'brace', name: '{', line: i + 1, col: pos + 1, text: lineText.trim() });
      pos++;
    } else if (char === '}') {
      // pop up to the last opened brace
      let found = false;
      for (let s = stack.length - 1; s >= 0; s--) {
        if (stack[s].type === 'brace') {
          stack.splice(s);
          found = true;
          break;
        }
      }
      if (!found) {
        console.log(`Unmatched '}' at Line ${i + 1}:${pos + 1} "${lineText.trim()}"`);
      }
      pos++;
    } else if (char === '(') {
      stack.push({ type: 'paren', name: '(', line: i + 1, col: pos + 1, text: lineText.trim() });
      pos++;
    } else if (char === ')') {
      let found = false;
      for (let s = stack.length - 1; s >= 0; s--) {
        if (stack[s].type === 'paren') {
          stack.splice(s);
          found = true;
          break;
        }
      }
      if (!found) {
        console.log(`Unmatched ')' at Line ${i + 1}:${pos + 1} "${lineText.trim()}"`);
      }
      pos++;
    } else if (char === '<') {
      // Check if it's a tag or comment
      if (lineText.substring(pos, pos + 4) === '<!--') {
        const endC = lineText.indexOf('-->', pos);
        pos = endC === -1 ? lineText.length : endC + 3;
        continue;
      }
      if (lineText.substring(pos, pos + 3) === '{/*') {
        const endC = lineText.indexOf('*/}', pos);
        pos = endC === -1 ? lineText.length : endC + 3;
        continue;
      }
      
      const endBracket = lineText.indexOf('>', pos);
      if (endBracket === -1) {
        pos++;
        continue;
      }
      
      const tagContent = lineText.substring(pos + 1, endBracket).trim();
      pos = endBracket + 1;
      
      if (tagContent.endsWith('/') || tagContent.startsWith('/*') || tagContent.startsWith('!') || tagContent.startsWith('{')) {
        continue;
      }
      
      if (tagContent.startsWith('/')) {
        const tagName = tagContent.substring(1).split(/[\s>]/)[0];
        if (voidTags.has(tagName)) continue;
        
        let found = false;
        for (let s = stack.length - 1; s >= 0; s--) {
          if (stack[s].type === 'tag' && stack[s].name === tagName) {
            stack.splice(s);
            found = true;
            break;
          }
        }
        if (!found) {
          console.log(`Unmatched closing tag </${tagName}> at Line ${i + 1} "${lineText.trim()}"`);
        }
      } else {
        const tagName = tagContent.split(/[\s>]/)[0];
        if (voidTags.has(tagName) || !/^[A-Za-z0-9:._\-]+$/.test(tagName)) continue;
        stack.push({ type: 'tag', name: tagName, line: i + 1, col: pos, text: lineText.trim() });
      }
    } else {
      pos++;
    }
  }
}

console.log("=== PARSE TREE STACK AT END ===");
console.log(stack.map(s => `${s.type.toUpperCase()}: ${s.name} (Line ${s.line} - "${s.text.substring(0, 40)}")`).join('\n'));
