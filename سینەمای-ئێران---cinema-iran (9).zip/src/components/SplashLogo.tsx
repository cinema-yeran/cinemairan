import React from 'react';

const SplashLogo = ({ className = "w-48 h-48" }: { className?: string }) => {
  return (
    <div className={`relative flex items-center justify-center ${className} select-none`} dir="ltr">
      <svg viewBox="0 0 500 500" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#f3f4f6" />
          </linearGradient>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fbbf24" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="100%" stopColor="#ca8a04" />
          </linearGradient>
          <filter id="logoShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="3" />
            <feOffset dx="0" dy="2" result="offsetblur" />
            <feComponentTransfer>
              <feFuncA type="linear" slope="0.4" />
            </feComponentTransfer>
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Logo Container - Precisely Centered */}
        <g transform="translate(250, 240)">
          
          {/* Main Symbols Section (C and E) */}
          <g transform="translate(-180, -100)" filter="url(#logoShadow)">
            
            {/* Lulo Clean Style - Geometric Bold C */}
            <path 
              d="M160 45 A 85 85 0 1 0 160 125 H 115 A 50 50 0 1 1 115 45 H 160 Z" 
              fill="url(#logoGradient)" 
            />
            
            {/* Golden Play Icon - Bold and Precisely Centered within C */}
            <path d="M78 58 V112 L128 85 L78 58 Z" fill="url(#goldGradient)" />

            {/* Clapperboard E */}
            <g transform="translate(200, 0)">
              {/* E Body */}
              <g>
                {/* Top bar (Clapper Lid) */}
                <g>
                  <rect width="145" height="40" fill="url(#logoGradient)" />
                  <path d="M5 40 L35 0 H60 L30 40 H5 Z" fill="#18181b" />
                  <path d="M50 40 L80 0 H105 L75 40 H50 Z" fill="#18181b" />
                  <path d="M95 40 L125 0 H145 V40 H95 Z" fill="#18181b" />
                </g>
                
                {/* Middle and Bottom Bars */}
                <rect y="70" width="130" height="35" fill="url(#logoGradient)" />
                <rect y="130" width="145" height="40" fill="url(#logoGradient)" />
                {/* Vertical Spine */}
                <rect width="40" height="170" fill="url(#logoGradient)" />
              </g>
            </g>
          </g>

          {/* Separator Line - Proportional and Tight */}
          <rect x="-185" y="85" width="375" height="3" fill="url(#logoGradient)" />

          {/* Brand Text - Bold Modern Montserrat Style */}
          <text 
            y="135" 
            fontFamily="Montserrat, sans-serif" 
            fontSize="48" 
            fontWeight="900"
            textAnchor="middle"
            letterSpacing="0.05em" 
            fill="url(#logoGradient)"
            className="uppercase"
          >
            CINEMAYERAN
          </text>
        </g>
      </svg>
    </div>
  );
};

export default SplashLogo;
