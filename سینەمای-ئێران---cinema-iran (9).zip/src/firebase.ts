import { getApp, getApps, initializeApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithRedirect, 
  getRedirectResult, 
  signOut, 
  onAuthStateChanged, 
  User, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile,
  setPersistence,
  browserLocalPersistence,
  sendPasswordResetEmail,
  verifyPasswordResetCode,
  confirmPasswordReset
} from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, serverTimestamp, collection, onSnapshot, updateDoc, writeBatch, addDoc, enableIndexedDbPersistence, query, where, getDocs } from 'firebase/firestore';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Enable offline persistence
if (typeof window !== 'undefined') {
  enableIndexedDbPersistence(db).catch((err) => {
    if (err.code === 'failed-precondition') {
      // Multiple tabs open, persistence can only be enabled in one tab at a time.
      console.warn("Firestore persistence failed: Multiple tabs open");
    } else if (err.code === 'unimplemented') {
      // The current browser does not support all of the features required to enable persistence
      console.warn("Firestore persistence not supported by browser");
    }
  });
}
export const auth = getAuth(app);
export const storage = getStorage(app);

// Use session persistence to avoid issues with some restrictive browsers
setPersistence(auth, browserLocalPersistence).catch(err => console.error("Persistence error:", err));

export const getMessagingSafe = () => {
  try {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator && window.location.protocol === 'https:') {
      return getMessaging(app);
    }
  } catch (e) {
    console.warn("Firebase Messaging not supported:", e);
  }
  return null;
};
export const messaging = getMessagingSafe();

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(`Firestore Error: ${JSON.stringify(errInfo)}`);
}

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Create or update user profile in Firestore
    const userRef = doc(db, 'users', user.uid);
    const path = `users/${user.uid}`;
    
    try {
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          displayName: user.displayName || 'بەکارهێنەر',
          email: user.email || '',
          photoURL: user.photoURL || null,
          status: 'pending',
          createdAt: serverTimestamp(),
        });
      } else {
        await setDoc(userRef, {
          updatedAt: serverTimestamp(),
        }, { merge: true });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
    
    return user;
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('Firestore Error')) {
      throw error;
    }
    const errorCode = error?.code || '';
    const errorMessage = error?.message || '';
    const isCancelled = errorCode === 'auth/popup-closed-by-user' || 
                        errorCode === 'auth/cancelled-by-user' ||
                        errorMessage.includes('closed by user') || 
                        errorMessage.includes('cancelled-by-user');
    if (!isCancelled) {
      console.error("Error signing in with Google", error);
    }
    throw error;
  }
};

export const signInWithGoogleRedirect = async () => {
  try {
    await signInWithRedirect(auth, googleProvider);
  } catch (error) {
    console.error("Error signing in with Google Redirect", error);
    throw error;
  }
};

export const handleRedirectResult = async () => {
  try {
    const result = await getRedirectResult(auth);
    if (result) {
      const user = result.user;
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          displayName: user.displayName || 'بەکارهێنەر',
          email: user.email || '',
          photoURL: user.photoURL || null,
          status: 'pending',
          createdAt: serverTimestamp(),
        });
      }
      return user;
    }
    return null;
  } catch (error) {
    console.error("Error handling redirect result", error);
    throw error;
  }
};

export const signInWithEmail = async (email: string, pass: string) => {
  try {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    return result.user;
  } catch (error) {
    console.error("Error signing in with email", error);
    throw error;
  }
};

export const loginWithIdentifier = async (identifier: string, pass: string) => {
  try {
    let trimmedId = identifier.trim();
    
    // Check if the trimmed identifier resembles a valid email format
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedId);
    
    if (!isEmail) {
      if (!trimmedId.includes('@') && trimmedId.length > 0) {
        try {
          const usersRef = collection(db, 'users');
          // 1. Try exact match query
          let q = query(usersRef, where("displayName", "==", trimmedId));
          let querySnapshot = await getDocs(q);
          
          // 2. Try lowercase match query if exact was empty
          if (querySnapshot.empty) {
            q = query(usersRef, where("displayName", "==", trimmedId.toLowerCase()));
            querySnapshot = await getDocs(q);
          }
          
          // 3. Try titlecase match query if still empty
          if (querySnapshot.empty) {
            const titleCased = trimmedId.charAt(0).toUpperCase() + trimmedId.slice(1).toLowerCase();
            q = query(usersRef, where("displayName", "==", titleCased));
            querySnapshot = await getDocs(q);
          }
          
          if (!querySnapshot.empty) {
            const userDoc = querySnapshot.docs[0];
            const userData = userDoc.data();
            if (userData && userData.email) {
              trimmedId = userData.email;
              console.log("Resolved displayName to matching user email:", trimmedId);
            } else {
              trimmedId = `${trimmedId.replace(/\s+/g, '_')}@cinemazone.com`;
            }
          } else {
            // Fallback: assume default dummy email layout
            trimmedId = `${trimmedId.replace(/\s+/g, '_')}@cinemazone.com`;
          }
        } catch (dbErr) {
          console.warn("Error resolving displayName in Firestore:", dbErr);
          trimmedId = `${trimmedId.replace(/\s+/g, '_')}@cinemazone.com`;
        }
      } else {
        const invalidEmailErr: any = new Error("Invalid email format");
        invalidEmailErr.code = 'auth/invalid-email';
        throw invalidEmailErr;
      }
    }

    const keyLower = trimmedId.toLowerCase();
    const overridePass = typeof window !== 'undefined' ? localStorage.getItem(`override_pass_${keyLower}`) : null;
    const cachedOldPass = typeof window !== 'undefined' ? localStorage.getItem(`cached_pwd_${keyLower}`) : null;

    if (overridePass && overridePass === pass && cachedOldPass) {
      // Self-healing flow: sign in using old cached password first, then update to new password
      try {
        const result = await signInWithEmailAndPassword(auth, trimmedId, cachedOldPass);
        if (result.user) {
          const { updatePassword } = await import('firebase/auth');
          await updatePassword(result.user, pass);
          localStorage.setItem(`cached_pwd_${keyLower}`, pass);
          localStorage.removeItem(`override_pass_${keyLower}`);
          return result.user;
        }
      } catch (selfHealErr) {
        console.warn("Self-healing login failed, falling back to direct sign in:", selfHealErr);
      }
    }

    try {
      const result = await signInWithEmailAndPassword(auth, trimmedId, pass);
      // Cache the successful password for future fallback/self-healing reset alignment
      if (typeof window !== 'undefined') {
        localStorage.setItem(`cached_pwd_${keyLower}`, pass);
      }
      return result.user;
    } catch (err: any) {
      throw err;
    }
  } catch (error: any) {
    if (error?.code !== 'auth/user-not-found' && error?.code !== 'auth/invalid-credential' && error?.code !== 'auth/wrong-password' && error?.code !== 'auth/invalid-email') {
      console.error("Error signing in with identifier", error);
    }
    throw error;
  }
};

export const registerWithEmail = async (email: string, pass: string, name: string, plan: string = 'monthly', phoneNumber?: string) => {
  try {
    // If dummy email needs to be generated
    const cleanPhone = (phoneNumber || '').replace(/\D/g, '');
    const finalEmail = email || (cleanPhone ? `${cleanPhone}@cinemazone.com` : `${name.replace(/\s+/g, '_')}@cinemazone.com`);
    
    const result = await createUserWithEmailAndPassword(auth, finalEmail, pass);
    const user = result.user;
    
    if (typeof window !== 'undefined') {
      localStorage.setItem(`cached_pwd_${finalEmail.toLowerCase()}`, pass);
    }
    
    await updateProfile(user, { displayName: name });

    // Create user profile in Firestore
    const userRef = doc(db, 'users', user.uid);
    const path = `users/${user.uid}`;
    
    try {
      await setDoc(userRef, {
        displayName: name,
        email: finalEmail,
        phoneNumber: phoneNumber || null,
        photoURL: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
        status: 'pending',
        plan: plan,
        createdAt: serverTimestamp(),
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
    
    return user;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Firestore Error')) {
      throw error;
    }
    console.error("Error registering with email", error);
    throw error;
  }
};

export const logout = () => signOut(auth);

export const sendResetPasswordEmail = async (email: string) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return true;
  } catch (error) {
    console.error("Error sending password reset email", error);
    throw error;
  }
};

export const handleVerifyPasswordResetCode = (oobCode: string) => verifyPasswordResetCode(auth, oobCode);
export const handleConfirmPasswordReset = (oobCode: string, newPass: string) => confirmPasswordReset(auth, oobCode, newPass);
