import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

let balance = 0;

for (let i = 8443; i <= 8870; i++) {
  const lineText = lines[i];
  if (!lineText) continue;
  
  // Find standard open / close tags checking tag content of <div vs </div>
  let pos = 0;
  while (true) {
    const nextBracket = lineText.indexOf('<', pos);
    if (nextBracket === -1) break;
    
    // Ignore comments
    if (lineText.substring(nextBracket, nextBracket + 4) === '<!--') {
      const endC = lineText.indexOf('-->', nextBracket);
      pos = endC === -1 ? lineText.length : endC + 3;
      continue;
    }
    if (lineText.substring(nextBracket, nextBracket + 3) === '{/*') {
      const endC = lineText.indexOf('*/}', nextBracket);
      pos = endC === -1 ? lineText.length : endC + 3;
      continue;
    }
    
    const endBracket = lineText.indexOf('>', nextBracket);
    if (endBracket === -1) {
      pos = nextBracket + 1;
      continue;
    }
    
    const tagContent = lineText.substring(nextBracket + 1, endBracket).trim();
    pos = endBracket + 1;
    
    // Self-closers
    if (tagContent.endsWith('/') || tagContent.startsWith('/*') || tagContent.startsWith('!') || tagContent.startsWith('{')) {
      continue;
    }
    
    if (tagContent.startsWith('/')) {
      const tagName = tagContent.substring(1).split(/[\s>]/)[0];
      if (tagName === 'div') {
        balance--;
        console.log(`Line ${i + 1}: Closing </div>. Balance = ${balance}`);
      }
    } else {
      const tagName = tagContent.split(/[\s>]/)[0];
      if (tagName === 'div') {
        balance++;
        console.log(`Line ${i + 1}: Opening <div [${tagContent.substring(0, 30)}...]. Balance = ${balance}`);
      }
    }
  }
}

console.log("FINAL BALANCE:", balance);
