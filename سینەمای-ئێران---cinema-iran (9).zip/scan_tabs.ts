import * as fs from 'fs';

const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');

for (let i = 5890; i < 8350; i++) {
  if (lines[i].includes('activeTab ===') && (lines[i].includes('?') || lines[i].includes('&&'))) {
    console.log(`Line ${i + 1}: ${lines[i].trim()}`);
  }
}
