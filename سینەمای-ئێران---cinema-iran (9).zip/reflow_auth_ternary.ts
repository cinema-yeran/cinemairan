import * as fs from 'fs';

const filePath = 'src/App.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// Replace standard ternary start
if (content.includes('{!user ? (')) {
  content = content.replace('{!user ? (', '{!user && (');
  console.log("Replaced start to {!user && (");
} else {
  // Try without space
  content = content.replace('{!user ?(', '{!user && (');
}

// Replace standard ternary middle
const middleTarget = `              </div>
            ) : (
                <div className="space-y-8 sm:space-y-12">`;

const middleReplacement = `              </div>
            )}
            {user && (
                <div className="space-y-8 sm:space-y-12">`;

if (content.includes(middleTarget)) {
  content = content.replace(middleTarget, middleReplacement);
  console.log("Replaced middle ternary to flat conditional blocks!");
} else {
  console.error("Middle pattern not found. Let's do a regex search.");
  const middleRegex = /<\/div>\s*<\/div>\s*\)\s*:\s*\(\s*<div className="space-y-8 sm:space-y-12">/;
  if (middleRegex.test(content)) {
    content = content.replace(middleRegex, `</div>\r\n              </div>\r\n            )}\r\n            {user && (\r\n                <div className="space-y-8 sm:space-y-12">`);
    console.log("Replaced middle using regex!");
  }
}

fs.writeFileSync(filePath, content, 'utf8');
