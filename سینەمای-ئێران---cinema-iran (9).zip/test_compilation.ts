import * as fs from 'fs';

const filePath = 'src/App.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// We want to replace specifically:
const oldBlock = `                  </div>
                </div>
              )}
            </motion.div>
          ) : null}
        </main>

        </div>
      )}`;

const newBlock = `                  </div>
              )}
            </motion.div>
          ) : null}
        </main>`;

if (content.includes(oldBlock)) {
  content = content.replace(oldBlock, newBlock);
  fs.writeFileSync(filePath, content, 'utf8');
  console.log("Successfully fixed the brackets and removed the premature app closures!");
} else {
  console.error("Old block pattern not found in `src/App.tsx`! Let's check with substring search.");
}
