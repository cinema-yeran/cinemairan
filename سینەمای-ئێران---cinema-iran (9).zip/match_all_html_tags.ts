import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

const stack: { tag: string; line: number; text: string }[] = [];

// Standard void/self-closing tags
const voidTags = new Set([
  'input', 'img', 'br', 'hr', 'meta', 'link', 'source', 'iframe', 'area', 'base', 'col', 'embed', 'keygen', 'param', 'track', 'wbr'
]);

for (let i = 8443; i <= 8870; i++) {
  const lineText = lines[i];
  if (!lineText) continue;
  
  let pos = 0;
  while (true) {
    const nextBracket = lineText.indexOf('<', pos);
    if (nextBracket === -1) break;
    
    // Check if it's a comment
    if (lineText.substring(nextBracket, nextBracket + 4) === '<!--') {
      const endC = lineText.indexOf('-->', nextBracket);
      pos = endC === -1 ? lineText.length : endC + 3;
      continue;
    }
    if (lineText.substring(nextBracket, nextBracket + 3) === '{/*') {
      const endC = lineText.indexOf('*/}', nextBracket);
      pos = endC === -1 ? lineText.length : endC + 3;
      continue;
    }
    
    const endBracket = lineText.indexOf('>', nextBracket);
    if (endBracket === -1) {
      pos = nextBracket + 1;
      continue;
    }
    
    const tagContent = lineText.substring(nextBracket + 1, endBracket).trim();
    pos = endBracket + 1;
    
    // Self-closers
    if (tagContent.endsWith('/') || tagContent.startsWith('/*') || tagContent.startsWith('!') || tagContent.startsWith('{')) {
      continue;
    }
    
    if (tagContent.startsWith('/')) {
      const tagName = tagContent.substring(1).split(/[\s>]/)[0];
      if (voidTags.has(tagName)) continue;
      
      if (stack.length === 0) {
        console.log(`Unmatched closing tag </${tagName}> at Line ${i + 1}: "${lineText.trim()}"`);
      } else {
        const last = stack[stack.length - 1];
        if (last.tag === tagName) {
          stack.pop();
        } else {
          console.log(`Mismatch: found </${tagName}> at Line ${i + 1} but expected </${last.tag}> (opened at Line ${last.line}: "${last.text}")`);
          // Pop to restore
          let matched = false;
          for (let s = stack.length - 1; s >= 0; s--) {
            if (stack[s].tag === tagName) {
              stack.splice(s);
              matched = true;
              break;
            }
          }
        }
      }
    } else {
      const tagName = tagContent.split(/[\s>]/)[0];
      // Skip type generics or JS comparisons
      if (voidTags.has(tagName) || !/^[A-Za-z0-9:._\-]+$/.test(tagName)) continue;
      stack.push({ tag: tagName, line: i + 1, text: lineText.trim() });
    }
  }
}

console.log("=== REMAINING HTML OPEN TAGS ===");
console.log(stack.map(s => `${s.tag} (Line ${s.line})`).join('\n'));
