import * as fs from 'fs';

const filePath = 'src/App.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// Regex matching the specific block
const regex = /([ \t]*)<\/div>\s*\r?\n\s*<\/div>\s*\r?\n\s*<\/div>\s*\r?\n\s*\{\s*isEditingProfile\s*&&/g;

if (regex.test(content)) {
  content = content.replace(regex, (match, prefix) => {
    // We want to return only two closed divs instead of three
    return `${prefix}</div>\r\n${prefix.substring(2)}</div>\r\n\r\n${prefix}{isEditingProfile &&`;
  });
  fs.writeFileSync(filePath, content, 'utf8');
  console.log("Successfully removed premature close tag using robust regex!");
} else {
  console.error("Robust regex didn't match. Let's do a substring locate.");
  const lines = content.split(/\r?\n/);
  // find lines 8542, 8543, 8544
  for (let i = 8530; i < 8560; i++) {
    console.log(`Line ${i+1}: "${lines[i]}"`);
  }
}
