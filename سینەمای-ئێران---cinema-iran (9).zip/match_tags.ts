import * as fs from 'fs';

const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');
const stack: { tag: string; line: number; text: string }[] = [];

const voidTags = new Set(['input', 'img', 'br', 'hr', 'meta', 'link', 'source', 'iframe']);

for (let i = 0; i < lines.length; i++) {
  const lineText = lines[i];
  
  let pos = 0;
  while (true) {
    const nextBracket = lineText.indexOf('<', pos);
    if (nextBracket === -1) break;
    
    // Check for comment
    if (lineText.substring(nextBracket, nextBracket + 4) === '<!--') {
      const endC = lineText.indexOf('-->', nextBracket);
      pos = endC === -1 ? lineText.length : endC + 3;
      continue;
    }
    if (lineText.substring(nextBracket, nextBracket + 3) === '{/*') {
      const endC = lineText.indexOf('*/}', nextBracket);
      pos = endC === -1 ? lineText.length : endC + 3;
      continue;
    }
    
    const endBracket = lineText.indexOf('>', nextBracket);
    if (endBracket === -1) {
      pos = nextBracket + 1;
      continue;
    }
    
    const tagContent = lineText.substring(nextBracket + 1, endBracket).trim();
    pos = endBracket + 1;
    
    // Self-closers
    if (tagContent.endsWith('/') || tagContent.startsWith('/*') || tagContent.startsWith('!') || tagContent.startsWith('{')) {
      continue;
    }
    
    if (tagContent.startsWith('/')) {
      const tagName = tagContent.substring(1).split(/[\s>]/)[0];
      if (voidTags.has(tagName)) continue;
      
      // Match from stack
      let matched = false;
      for (let s = stack.length - 1; s >= 0; s--) {
        if (stack[s].tag === tagName) {
          stack.splice(s, 1);
          matched = true;
          break;
        }
      }
    } else {
      const tagName = tagContent.split(/[\s>]/)[0];
      if (voidTags.has(tagName) || !/^[A-Za-z0-9:._\-]+$/.test(tagName)) continue;
      stack.push({ tag: tagName, line: i + 1, text: lineText });
    }
  }
}

console.log("STACK SUMMARY OF REMAINING OPEN TAGS:");
console.log(stack.map(s => `Line ${s.line}: <${s.tag}>`).join('\n'));
