import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

// We focus on lines 8444 to 8871 (index 8443 to 8870)
const divStack: { line: number; text: string }[] = [];

for (let i = 8443; i <= 8870; i++) {
  const lineText = lines[i];
  if (!lineText) continue;
  
  // Find all <div or </div> in the line
  let pos = 0;
  while (true) {
    const nextBracket = lineText.indexOf('<', pos);
    if (nextBracket === -1) break;
    
    const endBracket = lineText.indexOf('>', nextBracket);
    if (endBracket === -1) {
      pos = nextBracket + 1;
      continue;
    }
    
    const tagContent = lineText.substring(nextBracket + 1, endBracket).trim();
    pos = endBracket + 1;
    
    // Check if it is a comment or self-closing
    if (tagContent.startsWith('/*') || tagContent.startsWith('!') || tagContent.endsWith('/') || tagContent.startsWith('{')) {
      continue;
    }
    
    if (tagContent.startsWith('/')) {
      const tagName = tagContent.substring(1).split(/[\s>]/)[0];
      if (tagName === 'div') {
        if (divStack.length === 0) {
          console.log(`Extra </div> at Line ${i + 1}: "${lineText.trim()}"`);
        } else {
          divStack.pop();
        }
      }
    } else {
      const tagName = tagContent.split(/[\s>]/)[0];
      if (tagName === 'div') {
        divStack.push({ line: i + 1, text: lineText.trim() });
      }
    }
  }
}

console.log("=== DIV STACK REMAINING ===");
console.log("Total unclosed divs in this range:", divStack.length);
if (divStack.length > 0) {
  console.log(divStack.map(d => `Line ${d.line}: ${d.text}`).join('\n'));
}
