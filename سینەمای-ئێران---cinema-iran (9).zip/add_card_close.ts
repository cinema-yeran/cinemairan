import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split(/\r?\n/);

// Let's print lines 8540-8547 to verify indices
console.log("OLD line 8543:", lines[8542]);
console.log("OLD line 8544:", lines[8543]);
console.log("OLD line 8545:", lines[8544]);

// Insert </div> under line 8544 (index 8543 is line 8544)
lines.splice(8544, 0, '                  </div>');

fs.writeFileSync(filePath, lines.join('\r\n'), 'utf8');
console.log("Successfully closed the profile header card!");
