import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

const stack: { char: string; line: number; col: number; text: string }[] = [];

let inLineComment = false;
let inBlockComment = false;
let inStringDouble = false;
let inStringSingle = false;
let inTemplateLiteral = false;

for (let i = 0; i < lines.length; i++) {
  const lineText = lines[i] || '';
  inLineComment = false;
  
  for (let col = 0; col < lineText.length; col++) {
    const char = lineText[col];
    
    // Simple comment / string checks
    if (inLineComment) continue;
    if (inBlockComment) {
      if (char === '*' && lineText[col+1] === '/') {
        inBlockComment = false;
        col++;
      }
      continue;
    }
    
    if (inStringDouble) {
      if (char === '"' && lineText[col-1] !== '\\') inStringDouble = false;
      continue;
    }
    if (inStringSingle) {
      if (char === '\'' && lineText[col-1] !== '\\') inStringSingle = false;
      continue;
    }
    if (inTemplateLiteral) {
      if (char === '`' && lineText[col-1] !== '\\') inTemplateLiteral = false;
      continue;
    }
    
    if (char === '/' && lineText[col+1] === '/') {
      inLineComment = true;
      continue;
    }
    if (char === '/' && lineText[col+1] === '*') {
      inBlockComment = true;
      col++;
      continue;
    }
    
    if (char === '"') { inStringDouble = true; continue; }
    if (char === '\'') { inStringSingle = true; continue; }
    if (char === '`') { inTemplateLiteral = true; continue; }
    
    if (char === '(' || char === '{') {
      stack.push({ char, line: i + 1, col: col + 1, text: lineText.trim() });
    } else if (char === ')' || char === '}') {
      const expected = char === ')' ? '(' : '{';
      if (stack.length > 0) {
        const last = stack[stack.length - 1];
        if (last.char === expected) {
          stack.pop();
        } else {
          // Robust pop up to match to handle simple string template escapes
          let found = false;
          for (let s = stack.length - 1; s >= 0; s--) {
            if (stack[s].char === expected) {
              stack.splice(s);
              found = true;
              break;
            }
          }
        }
      }
    }
  }
}

console.log("=== BRIEF SUMMARY ===");
console.log("REMAINING OPEN CHR IN FULL FILE STACK:", stack.length);
if (stack.length > 0) {
  console.log("First 3 opened but unclosed things:");
  console.log(stack.slice(0, 3).map(s => `${s.char} (Line ${s.line}:${s.col} - ${s.text.substring(0, 80)})`).join('\n'));
  console.log("Last 3 opened but unclosed things:");
  console.log(stack.slice(-3).map(s => `${s.char} (Line ${s.line}:${s.col} - ${s.text.substring(0, 80)})`).join('\n'));
}
