import * as fs from 'fs';

const filePath = 'src/App.tsx';
let content = fs.readFileSync(filePath, 'utf8');

const startMarker = '                     {isEditingProfile && (';
const endMarker = '      {/* Mobile Side Menu */}';

const startIndex = content.indexOf(startMarker);
const endIndex = content.indexOf(endMarker);

if (startIndex === -1) {
  console.error("Start marker not found!");
  process.exit(1);
}

if (endIndex === -1) {
  console.error("End marker not found!");
  process.exit(1);
}

const replacement = `                     {isEditingProfile && (
                       <form onSubmit={handleUpdateProfile} className="w-full bg-white/5 backdrop-blur-3xl border border-white/10 p-8 rounded-[3rem] space-y-5 animate-in fade-in slide-in-from-top duration-700 shadow-3xl relative z-30 font-bold" dir="rtl">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-white/30 uppercase tracking-widest block pr-4 text-right">{t('newTitleLabel')}</label>
                            <input 
                              dir="rtl"
                              type="text"
                              value={tempDisplayName}
                              onChange={(e) => setTempDisplayName(e.target.value)}
                              className="w-full bg-black/60 border border-white/10 rounded-[1.5rem] py-4 px-6 text-white outline-none focus:border-orange-500 transition-all font-bold text-lg shadow-inner text-right"
                              placeholder={translations[language].fullNamePlaceholder}
                            />
                          </div>
                          <div className="space-y-2">
                            {/* Image Upload Area */}
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-white/30 uppercase tracking-widest block pr-4 text-right">
                                {language === 'ckb' ? "بارکردنی وێنەی سەرەکی" : "بارگذاری تصویر پروفایل"}
                              </label>
                              <div 
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  setIsDragOverProfile(true);
                                }}
                                onDragLeave={() => setIsDragOverProfile(false)}
                                onDrop={async (e) => {
                                  e.preventDefault();
                                  setIsDragOverProfile(false);
                                  const file = e.dataTransfer.files?.[0];
                                  if (file) {
                                    await uploadProfileFile(file);
                                  }
                                }}
                                className={\`w-full h-32 rounded-[1.5rem] border-2 border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer transition-all duration-300 group relative \${
                                  isDragOverProfile 
                                    ? 'border-orange-500 bg-orange-500/10 scale-[1.01]' 
                                    : 'border-white/15 bg-black/40 hover:border-orange-500/50 hover:bg-black/60'
                               }\`}
                              >
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  onChange={handleProfilePhotoUpload} 
                                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                                />
                                {isUploadingProfilePhoto ? (
                                  <div className="flex flex-col items-center gap-2">
                                    <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
                                    <span className="text-xs font-bold text-orange-500 animate-pulse">
                                      {language === 'ckb' ? "خەریکی بارکردنە..." : "در حال بارگذاری..."}
                                    </span>
                                  </div>
                                ) : (
                                  <div className="flex flex-col items-center gap-1.5 text-center p-4">
                                    <Upload className="w-5 h-5 text-white/40 group-hover:text-orange-500 transition-colors" />
                                    <span className="text-xs font-bold text-white/60">
                                      {language === 'ckb' 
                                        ? "کلیل بکە یان وێنەیەک لێرە دابنێ بۆ بارکردن" 
                                        : "کلیک کنید یا تصویر را در اینجا رها کنید"}
                                    </span>
                                    <span className="text-[9px] font-medium text-white/30">
                                      {language === 'ckb' ? "قەبارەی گونجاو: کەمتر لە ٥ مێگابایت" : "حجم مجاز: کمتر از ۵ مگابایت"}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>

                            <label className="text-[10px] font-black text-white/30 uppercase tracking-widest block pr-4 text-right">{t('imageLink')}</label>
                            <input 
                              type="url"
                              value={tempPhotoURL}
                              onChange={(e) => setTempPhotoURL(e.target.value)}
                              className="w-full bg-black/60 border border-white/10 rounded-[1.5rem] py-4 px-6 text-white outline-none focus:border-orange-500 transition-all text-xs font-mono shadow-inner text-center"
                              placeholder="https://..."
                            />
                          </div>
                          <button 
                            type="submit"
                            disabled={isSavingProfile}
                            className="w-full bg-orange-600 text-white py-4 rounded-[1.5rem] font-black text-base flex items-center justify-center gap-3 hover:bg-orange-700 transition-all shadow-2xl shadow-orange-600/40 active:scale-[0.98] cursor-pointer"
                          >
                            {isSavingProfile ? <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> : <Save className="w-5 h-5" />}
                            {t('saveChanges')}
                          </button>
                      </form>
                    )}

                    {/* Stats Grid - FOR ALL USERS - Optimized & Shrunk for Mobile */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 w-full pt-4 sm:pt-6">
                      {/* Joined Card */}
                      <div className="bg-[#1a1325]/40 border border-purple-500/10 p-2.5 sm:p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-1 sm:space-y-2 hover:border-purple-500/30 transition-all group cursor-default shadow-xl relative overflow-hidden h-full">
                        <div className="absolute inset-0 bg-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <Calendar className="w-4 h-4 sm:w-6 sm:h-6 text-purple-500 z-10" />
                        <div className="flex flex-col items-center z-10 w-full">
                          <span className="text-[8px] sm:text-[10px] font-black italic text-white/40 truncate uppercase tracking-widest leading-none mb-1">{t('joinedLabel')}</span>
                          <span className="text-xs sm:text-xl font-black italic tracking-tighter text-purple-400">{userProfile?.createdAt ? new Date(userProfile.createdAt.seconds * 1000).getFullYear() : 2026}</span>
                        </div>
                      </div>
                      
                      {/* Subtitled Card - ONLY FOR STAFF OR IF COUNT > 0 */}
                      {(isStaff || staffStats.subtitle > 0) && (
                        <div 
                          onClick={() => setActiveStatTab(activeStatTab === 'subtitle' ? null : 'subtitle')}
                          className={\`border p-2.5 sm:p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-1 sm:space-y-2 hover:border-blue-500/40 transition-all group cursor-pointer shadow-xl relative overflow-hidden h-full \${
                            activeStatTab === 'subtitle' ? 'bg-blue-600/20 border-blue-500/50' : 'bg-[#131a25]/40 border-white/5'
                          }\`}
                        >
                          <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                          <Film className="w-4 h-4 sm:w-6 sm:h-6 text-blue-500 z-10" />
                          <div className="flex flex-col items-center z-10 w-full">
                            <span className="text-[8px] sm:text-[10px] font-black italic text-white/40 truncate uppercase tracking-widest leading-none mb-1">{t('roleSubtitle')}</span>
                            <span className="text-xs sm:text-xl font-black italic tracking-tighter text-blue-400">{staffStats.subtitle}</span>
                          </div>
                        </div>
                      )}

                      {/* Translation Card */}
                      {(isStaff || staffStats.translation > 0) && (
                        <div 
                          onClick={() => setActiveStatTab(activeStatTab === 'translation' ? null : 'translation')}
                          className={\`border p-2.5 sm:p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-1 sm:space-y-2 hover:border-emerald-500/40 transition-all group cursor-pointer shadow-xl relative overflow-hidden h-full \${
                            activeStatTab === 'translation' ? 'bg-emerald-600/20 border-emerald-500/50' : 'bg-[#0c1c0c]/40 border-white/5'
                          }\`}
                        >
                          <div className="absolute inset-0 bg-emerald-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                          <Languages className="w-4 h-4 sm:w-6 sm:h-6 text-emerald-500 z-10" />
                          <div className="flex flex-col items-center z-10 w-full">
                            <span className="text-[8px] sm:text-[10px] font-black italic text-white/40 truncate uppercase tracking-widest leading-none mb-1">{t('translationCount')}</span>
                            <span className="text-xs sm:text-xl font-black italic tracking-tighter text-emerald-400">{staffStats.translation}</span>
                          </div>
                        </div>
                      )}

                      {/* Technical Card */}
                      {(isStaff || staffStats.technical > 0) && (
                        <div 
                          onClick={() => setActiveStatTab(activeStatTab === 'technical' ? null : 'technical')}
                          className={\`border p-2.5 sm:p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-1 sm:space-y-2 hover:border-rose-500/40 transition-all group cursor-pointer shadow-xl relative overflow-hidden h-full \${
                            activeStatTab === 'technical' ? 'bg-rose-600/20 border-rose-500/50' : 'bg-[#25131a]/40 border-white/5'
                          }\`}
                        >
                          <div className="absolute inset-0 bg-rose-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                          <Settings className="w-4 h-4 sm:w-6 sm:h-6 text-rose-500 z-10" />
                          <div className="flex flex-col items-center z-10 w-full">
                            <span className="text-[8px] sm:text-[10px] font-black italic text-white/40 truncate uppercase tracking-widest leading-none mb-1">{t('technicalCount')}</span>
                            <span className="text-xs sm:text-xl font-black italic tracking-tighter text-rose-400">{staffStats.technical}</span>
                          </div>
                        </div>
                      )}

                      {/* Ratings Card */}
                      <div 
                        onClick={() => setActiveStatTab(activeStatTab === 'ratings' ? null : 'ratings')}
                        className={\`border p-2.5 sm:p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-1 sm:space-y-2 hover:border-yellow-500/40 transition-all group cursor-pointer shadow-xl relative overflow-hidden h-full \${
                          activeStatTab === 'ratings' ? 'bg-yellow-600/20 border-yellow-500/50' : 'bg-[#252513]/40 border-white/5'
                        }\`}
                      >
                        <div className="absolute inset-0 bg-yellow-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <Star className="w-4 h-4 sm:w-6 sm:h-6 text-[#facc15] fill-current z-10" />
                        <div className="flex flex-col items-center z-10 w-full">
                          <span className="text-[8px] sm:text-[10px] font-black italic text-white/40 truncate uppercase tracking-widest leading-none mb-1">{t('ratingsCount')}</span>
                          <span className="text-xs sm:text-xl font-black italic tracking-tighter text-[#facc15]">{Object.keys(userMovieRatings).length}</span>
                        </div>
                      </div>

                      {/* Comments Card */}
                      <div 
                        onClick={() => setActiveStatTab(activeStatTab === 'comments' ? null : 'comments')}
                        className={\`border p-2.5 sm:p-5 rounded-2xl flex flex-col items-center justify-center text-center space-y-1 sm:space-y-2 hover:border-green-500/40 transition-all group cursor-pointer shadow-xl relative overflow-hidden h-full \${
                          activeStatTab === 'comments' ? 'bg-green-600/20 border-green-500/50' : 'bg-[#13251a]/40 border-white/5'
                        }\`}
                      >
                        <div className="absolute inset-0 bg-green-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <MessageSquare className="w-4 h-4 sm:w-6 sm:h-6 text-green-500 z-10" />
                        <div className="flex flex-col items-center z-10 w-full">
                          <span className="text-[8px] sm:text-[10px] font-black italic text-white/40 truncate uppercase tracking-widest leading-none mb-1">{t('commentsCount')}</span>
                          <span className="text-xs sm:text-xl font-black italic tracking-tighter text-green-400">{userComments.length}</span>
                        </div>
                      </div>
                    </div>

                    {/* Active Stat Content - Lists media under filtered categories dynamically */}
                    {activeStatTab && (
                      <div className="mt-4 p-4 md:p-6 bg-white/[0.03] border border-white/15 rounded-3xl w-full text-right animate-in fade-in duration-300">
                        <div className="flex items-center justify-between mb-4 flex-row-reverse border-b border-white/5 pb-3">
                          <h4 className="text-sm font-black text-white italic">
                            {activeStatTab === 'subtitle' && (language === 'fa' ? 'آثار زیرنویس شده' : 'بەرهەمە ژێرنووسکراوەکان')}
                            {activeStatTab === 'translation' && (language === 'fa' ? 'آثار ترجمه شده' : 'بەرهەمە وەرگێڕدراوەکان')}
                            {activeStatTab === 'technical' && (language === 'fa' ? 'آثار کار فنی' : 'بەرهەمە تەکنیکییەکان')}
                            {activeStatTab === 'ratings' && (language === 'fa' ? 'آثاری که امتیاز داده‌اید' : 'ئەو بەرهەمانەی هەڵسەنگاندنت بۆ کردوون')}
                            {activeStatTab === 'comments' && (language === 'fa' ? 'آثاری که نظر داده‌اید' : 'ئەو بەرهەمانەی بۆچوونت لەسەر نووسیون')}
                          </h4>
                          <button 
                            type="button"
                            onClick={() => setActiveStatTab(null)}
                            className="text-xs text-orange-500 hover:text-white transition-colors cursor-pointer"
                          >
                            {language === 'fa' ? 'بستن' : 'داخستن'}
                          </button>
                        </div>

                        {/* Responsive grid for filtered results */}
                        <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                          {(() => {
                            const allMedia = [...movies, ...series, ...podcasts];
                            let filtered: any[] = [];
                            if (activeStatTab === 'subtitle') {
                              filtered = allMedia.filter(m => (m as any).subtitler === userProfile?.displayName);
                            } else if (activeStatTab === 'translation') {
                              filtered = allMedia.filter(m => (m as any).translator === userProfile?.displayName);
                            } else if (activeStatTab === 'technical') {
                              filtered = allMedia.filter(m => (m as any).technical === userProfile?.displayName);
                            } else if (activeStatTab === 'ratings') {
                              filtered = allMedia.filter(m => userMovieRatings[m.id] !== undefined);
                            } else if (activeStatTab === 'comments') {
                              const commentedIds = userComments.map(c => c.mediaId);
                              filtered = allMedia.filter(m => commentedIds.includes(m.id));
                            }

                            if (filtered.length === 0) {
                              return (
                                <p className="col-span-full py-8 text-center text-xs text-white/30 font-bold">
                                  {language === 'fa' ? 'هیچ اثری یافت نشد' : 'هیچ بەرهەمێک نەدۆزرایەوە'}
                                </p>
                              );
                            }

                            return filtered.map((media) => (
                              <div 
                                key={media.id}
                                onClick={() => {
                                  setSelectedMovie(media);
                                  window.scrollTo({ top: 0, behavior: 'smooth' });
                                }}
                                className="group bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 transform hover:scale-[1.03]"
                              >
                                <div className="aspect-[2/3] relative overflow-hidden bg-neutral-900 border-b border-white/5">
                                  {media.image && media.image.trim() !== '' ? (
                                    <img src={media.image} referrerPolicy="no-referrer" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" alt="" />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center">
                                      <Film className="w-6 h-6 text-white/10" />
                                    </div>
                                  )}
                                  {activeStatTab === 'ratings' && (
                                    <div className="absolute top-1.5 right-1.5 bg-black/60 backdrop-blur-md border border-yellow-500/30 px-1.5 py-0.5 rounded-md text-[9px] font-black text-yellow-500 flex items-center gap-0.5">
                                      <Star className="w-2.5 h-2.5 fill-current" />
                                      {userMovieRatings[media.id]}
                                    </div>
                                  )}
                                </div>
                                <div className="p-2 text-right">
                                  <h5 className="text-[10px] font-black text-white truncate leading-tight">{getDisplayTitle(media)}</h5>
                                </div>
                              </div>
                            ));
                          })()}
                        </div>
                      </div>
                    )}

                    {/* Admin Dashboard Control Panel */}
                    {isAdmin && (
                      <div className="w-full pt-8 border-t border-white/5 space-y-4 text-right" dir="rtl">
                        <div className="flex items-center gap-2 mb-2 justify-end">
                          <span className="text-sm font-black italic tracking-tight text-white/50">{language === 'ckb' ? 'بەشی بەڕێوەبەرایەتی' : 'بخش مدیریت'}</span>
                          <ShieldCheck className="w-5 h-5 text-orange-500" />
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {/* Manage Members Card */}
                          <div 
                            onClick={() => setActiveTab('members')}
                            className="bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/20 hover:border-orange-500/40 p-5 rounded-2xl flex items-center justify-between cursor-pointer transition-all duration-300 transform hover:scale-[1.02] shadow-xl group relative overflow-hidden"
                          >
                            <div className="absolute inset-0 bg-gradient-to-r from-orange-500/0 via-orange-500/5 to-orange-500/0 -translate-x-full group-hover:translate-x-full transition-transform duration-[1.5s]" />
                            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-orange-500/20 text-orange-500 shrink-0">
                              <Users className="w-6 h-6" />
                            </div>
                            <div className="text-right">
                              <h4 className="text-sm font-black text-white">{t('manageMembers')}</h4>
                              <p className="text-[10px] text-white/40 mt-1 font-bold">
                                {language === 'ckb' ? \`\${allUsers.length} ئەندام تۆمارکراوە\` : \`\${allUsers.length} کاربر ثبت شده\`}
                              </p>
                              {allUsers.some(u => u.status === 'pending') && (
                                <span className="inline-block bg-red-600 text-white text-[8px] font-black px-2 py-0.5 rounded-full mt-2 animate-bounce">
                                  {language === 'ckb' ? 'داواکاری نوێ هەیە' : 'درخواست جدید وجود دارد'}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Seed Data Card */}
                          <div 
                            onClick={seedMovies}
                            className="bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 hover:border-blue-500/40 p-5 rounded-2xl flex items-center justify-between cursor-pointer transition-all duration-300 transform hover:scale-[1.02] shadow-xl group relative overflow-hidden"
                          >
                            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/0 via-blue-500/5 to-blue-500/0 -translate-x-full group-hover:translate-x-full transition-transform duration-[1.5s]" />
                            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-blue-500/20 text-blue-500 shrink-0">
                              <Zap className="w-6 h-6" />
                            </div>
                            <div className="text-right">
                              <h4 className="text-sm font-black text-white">{t('refreshData')}</h4>
                              <p className="text-[10px] text-white/40 mt-1 font-bold">
                                {language === 'ckb' ? 'نوێکردنەوە یان ڕێکخستنەوەی زانیاری سەرەکی' : 'بروزرسانی یا ست‌آپ داده‌های اصلی'}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Logout Button - Separate and Visible */}
                    <div className="w-full pt-6 border-t border-white/5">
                      <button 
                        type="button"
                        onClick={handleLogout}
                        className="w-full group relative overflow-hidden bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white py-4 rounded-2xl font-black italic uppercase tracking-[0.2em] flex items-center justify-center gap-4 transition-all duration-500 shadow-2xl shadow-red-600/10 hover:shadow-red-600/40 border border-red-600/20 hover:border-red-500 cursor-pointer"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                        <LogOut className="w-5 h-5 group-hover:translate-x-1 transition-transform rotate-180" />
                        <span className="text-xs sm:text-sm font-black">{t('logout')}</span>
                      </button>
                    </div>

                  </div>
                </div>
              )}
            </motion.div>
          ) : null}
        </main>

        </div>
      )}

      {/* Advanced Footer */}
      <footer className="bg-[#0a0a0a] border-t border-white/5 pt-10 md:pt-20 pb-8 px-3 sm:px-6 md:px-12 relative overflow-hidden">
        {/* Decorative Background */}
        <div className="absolute bottom-0 right-0 w-[400px] md:w-[600px] h-[400px] md:h-[600px] bg-orange-600/5 blur-[120px] rounded-full pointer-events-none" />
        
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-8 md:gap-24">
          {/* Brand Column */}
          <div className="flex-1 space-y-4 md:space-y-6 text-right">
            <div className="flex flex-col items-start gap-2 md:gap-3">
              <div className="w-24 h-24 md:w-32 md:h-32 group relative">
                <div className="absolute inset-0 bg-orange-500 rounded-2xl blur-xl opacity-0 group-hover:opacity-40 transition-opacity" />
                <SplashLogo className="w-full h-full group-hover:scale-110 transition-all duration-500 z-10 relative" />
              </div>
              <h2 className="text-xl md:text-4xl font-black text-white italic tracking-tighter mt-1 md:mt-4 uppercase" dir="rtl">
                سینەمای <span className="text-orange-500">ئێران</span>
              </h2>
            </div>
            
            <p className="text-white/40 text-[10px] md:text-sm font-medium leading-relaxed max-w-sm ml-0 mr-auto" dir="rtl">
              {t('footerDesc')}
            </p>

            <div className="flex flex-wrap justify-start gap-2 md:gap-3">
              {[
                { icon: <Instagram className="w-3 h-3 md:w-5 md:h-5" />, href: siteSettings.socialLinks.instagram },
                { icon: <Music2 className="w-3 h-3 md:w-5 md:h-5" />, href: siteSettings.socialLinks.tiktok },
                { icon: <Send className="w-3 h-3 md:w-5 md:h-5" />, href: siteSettings.socialLinks.telegram },
                { icon: <Facebook className="w-3 h-3 md:w-5 md:h-5" />, href: siteSettings.socialLinks.facebook },
                { icon: <Ghost className="w-3 h-3 md:w-5 md:h-5" />, href: (siteSettings.socialLinks as any).snapchat }
              ].map((social, i) => (
                <a 
                  key={i} 
                  href={social.href} 
                  target="_blank" 
                  rel="noreferrer"
                  className="w-8 h-8 md:w-12 md:h-12 rounded-lg md:rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-orange-500 hover:border-orange-500/50 hover:bg-orange-500/5 hover:scale-110 active:scale-95 transition-all duration-300"
                >
                  {social.icon}
                </a>
              ))}
            </div>

            {isAdmin && (
              <div className="flex justify-start pt-4">
                <button 
                  type="button"
                  onClick={() => setIsEditingSettings(true)}
                  className="flex items-center gap-2 bg-orange-600/10 text-orange-500 border border-orange-600/20 px-3 py-1.5 md:px-4 md:py-2 rounded-xl text-[7px] md:text-[10px] font-black uppercase tracking-widest hover:bg-orange-600 hover:text-white transition-all shadow-lg cursor-pointer"
                >
                  <Edit3 className="w-2.5 h-2.5 md:w-3 md:h-3" />
                  {t('editInfo')}
                </button>
              </div>
            )}
          </div>

          {/* Links Column */}
          <div className="flex-1 space-y-6 md:space-y-8 text-right">
            <div className="flex items-center justify-start gap-3 md:gap-4">
              <h3 className="text-base md:text-2xl font-black italic text-orange-500">{t('quickLinks')}</h3>
              <div className="w-5 h-1 md:w-6 md:h-1 bg-orange-600 rounded-full" />
            </div>
            
            <nav className="flex flex-col gap-2.5 md:gap-5">
              {[
                { label: t('home'), icon: <Home className="w-3.5 h-3.5 md:w-5 md:h-5" />, onClick: () => { setView('list'); setActiveSection('all'); window.scrollTo(0, 0); } },
                { label: t('movies'), icon: <Film className="w-3.5 h-3.5 md:w-5 md:h-5" />, onClick: () => { setView('list'); setActiveSection('movies'); window.scrollTo(0, 0); } },
                { label: t('series'), icon: <Tv className="w-3.5 h-3.5 md:w-5 md:h-5" />, onClick: () => { setView('list'); setActiveSection('series'); window.scrollTo(0, 0); } },
                { label: t('watchlist'), icon: <Bookmark className="w-3.5 h-3.5 md:w-5 md:h-5" />, onClick: () => { setView('list'); setActiveTab('bookmarks'); window.scrollTo(0, 0); } },
                { label: t('staffFamily'), icon: <Users className="w-3.5 h-3.5 md:w-5 md:h-5" />, onClick: () => { setView('list'); setActiveTab('staff'); setSelectedStaffMember(null); window.scrollTo(0, 0); } }
              ].map((link, i) => (
                <button 
                  key={i} 
                  type="button"
                  onClick={link.onClick}
                  className="flex items-center justify-start gap-3 md:gap-4 text-white/40 hover:text-white transition-all group font-black italic uppercase tracking-widest text-[10px] md:text-xs text-right cursor-pointer"
                >
                  <div className="w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl bg-white/5 flex items-center justify-center text-white/20 group-hover:bg-orange-500/10 group-hover:text-orange-500 transition-all">
                    {link.icon}
                  </div>
                  <span className="group-hover:translate-x-[4px] transition-transform">{link.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Contact Column */}
          <div className="flex-1 space-y-6 md:space-y-10 text-right">
            <div className="flex items-center justify-start gap-3 md:gap-4">
              <h3 className="text-base md:text-2xl font-black italic text-orange-500">{t('contact')}</h3>
              <div className="w-5 h-1 md:w-6 md:h-1 bg-orange-600 rounded-full" />
            </div>

            <div className="space-y-4 md:space-y-5">
              <a 
                href="mailto:cinemayeran@gmail.com" 
                className="flex items-center justify-start gap-3 md:gap-4 group"
              >
                <div className="w-8 h-8 md:w-12 md:h-12 rounded-lg md:rounded-2xl bg-white/5 flex items-center justify-center text-white/20 group-hover:bg-orange-500/10 group-hover:text-orange-500 transition-all">
                  <Mail className="w-4 h-4 md:w-6 md:h-6" />
                </div>
                <span className="text-[12px] md:text-lg font-black text-white/60 group-hover:text-white transition-colors">cinemayeran@gmail.com</span>
              </a>

              <div className="flex flex-col gap-2.5 md:gap-4 pt-1.5 md:pt-2">
                <button 
                  type="button"
                  onClick={() => siteSettings.footerButtons.primaryLink && window.open(siteSettings.footerButtons.primaryLink, '_blank')}
                  className="w-full bg-orange-600/10 border border-orange-600/20 text-orange-500 py-3 md:py-4 rounded-xl md:rounded-3xl font-black italic hover:bg-orange-600 hover:text-white hover:border-orange-600 transition-all shadow-xl shadow-orange-600/10 active:scale-[0.98] text-[11px] md:text-sm cursor-pointer"
                >
                  {siteSettings.footerButtons.primary}
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    if (siteSettings.footerButtons.secondaryLink === 'staff') {
                      setView('list');
                      setActiveTab('staff');
                      window.scrollTo(0, 0);
                    } else if (siteSettings.footerButtons.secondaryLink) {
                      window.open(siteSettings.footerButtons.secondaryLink, '_blank');
                    }
                  }}
                  className="w-full bg-[#141414] border border-orange-600/20 text-orange-500 py-3 md:py-4 rounded-xl md:rounded-3xl font-black italic hover:scale-[1.02] transition-all shadow-xl active:scale-[0.98] text-[11px] md:text-sm cursor-pointer"
                >
                  {siteSettings.footerButtons.secondary}
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto mt-12 md:mt-20 pt-8 md:pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 md:gap-8">
          <p className="text-white/20 text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-center">
            © 2026 {siteSettings.footerBrand}. {t('allRightsReserved')}
          </p>
          <div className="flex gap-6 md:gap-8 text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] text-white/10">
            <a href="#" className="hover:text-orange-500 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-orange-500 transition-colors font-bold">Terms of Service</a>
          </div>
        </div>
      </footer>
`;

const newContent = content.substring(0, startIndex) + replacement + content.substring(endIndex);
fs.writeFileSync(filePath, newContent, 'utf8');
console.log("Successfully replaced the corrupted region in `/src/App.tsx`!");
