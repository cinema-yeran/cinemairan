const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetStart = '                             {(!editForm.';
const targetEnd = '                           {isUploadingMovie ? (';

const startIdx = code.indexOf(targetStart);
const endIdx = code.indexOf(targetEnd);

if (startIdx !== -1 && endIdx !== -1) {
  const replacement = `                             {(!editForm.episodesList || editForm.episodesList.length === 0) && (
                               <div className="text-center py-6 border-2 border-dashed border-white/5 rounded-2xl">
                                 <p className="text-white/20 text-[10px] font-bold italic uppercase">لیستی ئەڵقەکان بەتاڵە</p>
                               </div>
                             )}
                           </div>
                         </div>
                       </div>
                     )}
                   </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-white/30 pr-2">
                         {language === 'fa' ? 'پوستر عمودی' : 'وێنەی پۆستەری ستوونی (سەرەکی)'}
                       </label>
                       <div className="flex gap-2">
                         <input 
                            className="flex-1 bg-white/5 border border-white/10 p-4 rounded-xl font-bold text-white text-xs" 
                            value={editForm.image} 
                            onChange={e => setEditForm({...editForm, image: e.target.value})} 
                            placeholder="URL..." 
                         />
                         <button 
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={isUploadingPoster}
                            className="bg-orange-500/10 hover:bg-orange-500/20 text-orange-500 p-4 rounded-xl border border-orange-500/20 transition-all active:scale-95 flex items-center justify-center min-w-[56px]"
                            title="بارکردنی وێنە"
                         >
                            {isUploadingPoster ? (
                              <div className="w-5 h-5 border-2 border-orange-500/20 border-t-orange-500 rounded-full animate-spin" />
                            ) : (
                              <Camera className="w-5 h-5" />
                            )}
                         </button>
                       </div>
                    </div>

                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-white/30 pr-2">
                         {language === 'fa' ? 'تصویر پس’زمینه (افقی)' : 'وێنەی پشتەوەی پۆستەری سەرەکی (ئاسۆیی - پان)'}
                       </label>
                       <div className="flex gap-2">
                         <input 
                            className="flex-1 bg-white/5 border border-white/10 p-4 rounded-xl font-bold text-white text-xs" 
                            value={(editForm as any).backdropUrl || ''} 
                            onChange={e => setEditForm({...editForm, backdropUrl: e.target.value})} 
                            placeholder="URL..." 
                         />
                         <button 
                            type="button"
                            onClick={() => backdropFileInputRef.current?.click()}
                            disabled={isUploadingBackdrop}
                            className="bg-orange-500/10 hover:bg-orange-500/20 text-orange-500 p-4 rounded-xl border border-orange-500/20 transition-all active:scale-95 flex items-center justify-center min-w-[56px]"
                            title="بارکردنی پاشبنەما"
                         >
                            {isUploadingBackdrop ? (
                              <div className="w-5 h-5 border-2 border-orange-500/20 border-t-orange-500 rounded-full animate-spin" />
                            ) : (
                              <Camera className="w-5 h-5" />
                            )}
                         </button>
                       </div>
                    </div>

                    <div className="space-y-2">
                     <div className="space-y-2 bg-white/[0.02] border border-white/5 p-4 rounded-2xl mb-4">
                        <label className="text-[10px] font-black uppercase text-orange-500 pr-2 block text-right">
                          {language === 'fa' ? 'نوع نمایش پوستر در صفحه اصلی' : 'شێوازی نیشاندانی پۆستەر لەسەر لاپەڕەی سەرەکی (Slider)'}
                        </label>
                        <div className="grid grid-cols-2 gap-3 mt-1" dir="rtl">
                          <button
                            type="button"
                            onClick={() => setEditForm({...editForm, homePosterType: 'vertical'})}
                            className={\`py-3 px-4 rounded-xl text-[10px] font-black transition-all border flex flex-col items-center gap-1 \${
                              (editForm as any).homePosterType === 'vertical'
                                ? 'bg-orange-600 border-orange-500 text-white shadow-lg shadow-orange-600/20'
                                : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10'
                            }\`}
                          >
                            <span className="text-sm">📱</span>
                            <span>{language === 'fa' ? 'پوستر عمودی' : 'پۆستەری ستوونی (Vertical)'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditForm({...editForm, homePosterType: 'horizontal'})}
                            className={\`py-3 px-4 rounded-xl text-[10px] font-black transition-all border flex flex-col items-center gap-1 \${
                              (editForm as any).homePosterType === 'horizontal' || !(editForm as any).homePosterType
                                ? 'bg-orange-600 border-orange-500 text-white shadow-lg shadow-orange-600/20'
                                : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10'
                            }\`}
                          >
                            <span className="text-sm">🖥️</span>
                            <span>{language === 'fa' ? 'تصویر افقی (پشتی)' : 'وێنەی پشتەوەی پان (Backdrop)'}</span>
                          </button>
                        </div>
                     </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-white/30 pr-2">بەستەری ڤیدیۆ / دەنگ</label>
                      <div className="flex gap-2">
                        <input 
                          className="flex-1 bg-white/5 border border-white/10 p-4 rounded-xl font-bold text-white text-xs" 
                          value={editForm.movieUrl} 
                          onChange={e => setEditForm({...editForm, movieUrl: e.target.value})} 
                          placeholder="URL..." 
                        />
                        <button 
                           type="button"
                           onClick={() => {
                             setActiveEpisodeIdx(null);
                             setTimeout(() => movieFileInputRef.current?.click(), 0);
                           }}
                           disabled={isUploadingMovie}
                           className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-500 p-4 rounded-xl border border-blue-500/20 transition-all active:scale-95 flex items-center justify-center min-w-[56px]"
                           title="بارکردنی ڤیدیۆ / دەنگ"
                        >
                           {isUploadingMovie ? (
                             <div className="w-5 h-5 border-2 border-blue-500/20 border-t-blue-500 rounded-full animate-spin" />
                           ) : (`;
  
  code = code.substring(0, startIdx) + replacement + code.substring(endIdx + targetEnd.length);
  fs.writeFileSync('src/App.tsx', code, 'utf8');
  console.log('Successfully completed cleanup of nested blocks!');
} else {
  console.error('Start or end index not found!');
}
