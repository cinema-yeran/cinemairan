import * as fs from 'fs';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

const targetLines = lines.slice(8443, 8876);
const block = targetLines.join('\n');

const stack: { name: string; line: number; text: string }[] = [];
const voidTags = new Set([
  'input', 'img', 'br', 'hr', 'meta', 'link', 'source', 'iframe', 'area'
]);

let pos = 0;
while (pos < block.length) {
  const nextOpen = block.indexOf('<', pos);
  if (nextOpen === -1) break;
  
  if (block.substring(nextOpen, nextOpen + 4) === '<!--') {
    const nextClose = block.indexOf('-->', nextOpen);
    pos = nextClose === -1 ? block.length : nextClose + 3;
    continue;
  }
  if (block.substring(nextOpen, nextOpen + 3) === '{/*') {
    const nextClose = block.indexOf('*/}', nextOpen);
    pos = nextClose === -1 ? block.length : nextClose + 3;
    continue;
  }
  
  const endBracket = block.indexOf('>', nextOpen);
  if (endBracket === -1) {
    pos = nextOpen + 1;
    continue;
  }
  
  const rawTag = block.substring(nextOpen + 1, endBracket).trim();
  pos = endBracket + 1;
  
  if (rawTag.endsWith('/') || rawTag.startsWith('/*') || rawTag.startsWith('!') || rawTag.startsWith('{')) {
    continue;
  }
  
  const beforeStr = block.substring(0, nextOpen);
  const subLine = beforeStr.split('\n').length;
  const actualLine = 8444 + subLine - 1;

  if (rawTag.startsWith('/')) {
    const name = rawTag.substring(1).trim().split(/[\s>]/)[0];
    if (voidTags.has(name)) continue;
    
    if (stack.length === 0) {
      console.log(`[Line ${actualLine}] POP EMPTY for </${name}>`);
    } else {
      const top = stack.pop();
      console.log(`[Line ${actualLine}] POP </${name}> - matched with <${top?.name}> from Line ${top?.line}`);
      if (top?.name !== name) {
        console.log(`>>> MISMATCH at Line ${actualLine}! Expected </${top?.name}>`);
      }
    }
  } else {
    const name = rawTag.split(/[\s>]/)[0];
    if (voidTags.has(name) || !/^[A-Za-z0-9:._\-]+$/.test(name)) continue;
    
    stack.push({ name, line: actualLine, text: lines[actualLine - 1] });
    console.log(`[Line ${actualLine}] PUSH <${name}>`);
  }
}
